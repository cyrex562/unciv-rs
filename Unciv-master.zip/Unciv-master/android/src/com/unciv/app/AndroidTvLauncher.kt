package com.unciv.app

/**
 *  Proxy without functionality, referenced in AndroidManifest.xml for intent.category.LEANBACK_LAUNCHER
 */
class AndroidTvLauncher : AndroidLauncher()
