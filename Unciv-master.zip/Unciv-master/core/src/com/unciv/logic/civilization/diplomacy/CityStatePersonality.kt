package com.unciv.logic.civilization.diplomacy

enum class CityStatePersonality {
    Friendly,
    Neutral,
    Hostile,
    Irrational
}
