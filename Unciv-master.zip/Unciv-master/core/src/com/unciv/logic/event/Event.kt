package com.unciv.logic.event

/**
 * Base interface for all events. Use your IDE to list implementing subtypes to list all events available.
 */
interface Event
