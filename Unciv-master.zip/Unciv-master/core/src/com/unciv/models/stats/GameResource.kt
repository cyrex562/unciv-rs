package com.unciv.models.stats

interface GameResource {
    val name: String
}
